# coding_puzzles

Programming language quiz app with interactive python coding arena.

## Getting Started

Register with IITM Bsc students email id.
Go to Dashboard
Select any language and practice
Progress will be visible on dashboard along with reset button
For more help go through 'Manual.pdf'

