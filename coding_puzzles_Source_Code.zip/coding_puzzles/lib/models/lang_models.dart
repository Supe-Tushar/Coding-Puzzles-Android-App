// php data object to convert firebase data

class PhpData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  PhpData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}

class HtmlData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  HtmlData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class CssData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  CssData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class JsData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  JsData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class JavaData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  JavaData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class SqlData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  SqlData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class LinuxData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  LinuxData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class DbData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  DbData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}


class ComNetData {
  final dynamic qno;
  final dynamic question;
  final dynamic correct_ans;
  final dynamic optionA ;
  final dynamic optionB ;
  final dynamic optionC ;
  final dynamic optionD ;

  ComNetData({
    this.qno, this.question, this.correct_ans, this.optionA, this.optionB, this.optionC, this.optionD,
  });
}
