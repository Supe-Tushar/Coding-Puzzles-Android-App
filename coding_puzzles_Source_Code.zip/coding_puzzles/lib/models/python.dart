// python data object to convert firebase data

class PythonData {
  final dynamic qno;
  final dynamic rel_qno;
  final dynamic level;
  final dynamic question;
  final dynamic lines_wrong;
  final dynamic lines_correct;

  PythonData({
    this.qno,
    this.rel_qno,
    this.level,
    this.question,
    this.lines_wrong,
    this.lines_correct,
  });
}
