class UserC {
  // user data gathered from auth.dart. It contains a lot of fields
  // we will user personalised User class to get only required data.

  // uid is given dynamic type bcoz it may take value null (it wont take null
  // actually bcoz of function _userFromFirebaseUser in auth.dart)

  final dynamic uid; // user id sent by firebase

  UserC({ this.uid }); // UserC class constructor
  // User is class used by Firebase so our private class named to UserC

}

// convert user data collected from firebase into custom object
class UserData {
  final dynamic uid;
  final dynamic username;
  final dynamic useremail;
  final dynamic python_cq;
  final dynamic sql_cq;
  final dynamic html_cq;
  final dynamic css_cq;
  final dynamic js_cq;
  final dynamic php_cq;
  final dynamic java_cq;
  final dynamic linux_cq;
  final dynamic cpp_cq;
  final dynamic db_cq;
  final dynamic comnet_cq;

  UserData( {
    this.uid,
    this.username,
    this.useremail,
    this.python_cq,
    this.sql_cq,
    this.html_cq,
    this.css_cq,
    this.js_cq,
    this.php_cq,
    this.java_cq,
    this.linux_cq,
    this.cpp_cq,
    this.db_cq,
    this.comnet_cq,

});
}