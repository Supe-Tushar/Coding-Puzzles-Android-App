import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:coding_puzzles/models/user.dart';
import 'package:coding_puzzles/models/python.dart';
import 'package:coding_puzzles/models/lang_models.dart';

//import 'package:fluttertoast/fluttertoast.dart';

// Firestore is cloud database and its NoSQL (Not only SQL)
// Relational model changed slightly to get NoSQL model


class DatabaseService {

  final dynamic uid; //uid must be string
  int? py_qno;
  int? php_qno;
  int? html_qno;
  int? css_qno;
  int? js_qno;
  int? java_qno;
  int? sql_qno;
  int? linux_qno;
  int? db_qno;
  int? comnet_qno;

  DatabaseService({
    this.uid,
    this.py_qno = 1,
    this.php_qno = 1,
    this.html_qno = 1,
    this.css_qno = 1,
    this.js_qno = 1,
    this.java_qno = 1,
    this.sql_qno = 1,
    this.linux_qno = 1,
    this.db_qno = 1,
    this.comnet_qno = 1,
  });

  // collection reference

  // profiles: to store user email and name and progress
  final CollectionReference profileCollection = FirebaseFirestore.instance.collection('profiles');

  // Language collections
  final CollectionReference pythonCollection = FirebaseFirestore.instance.collection('python');
  final CollectionReference CSSCollection = FirebaseFirestore.instance.collection('CSS');
  final CollectionReference ComNetCollection = FirebaseFirestore.instance.collection('ComNet');
  final CollectionReference DBCollection = FirebaseFirestore.instance.collection('DB');
  final CollectionReference HTMLCollection = FirebaseFirestore.instance.collection('HTML');
  final CollectionReference JSCollection = FirebaseFirestore.instance.collection('JS');
  final CollectionReference JavaCollection = FirebaseFirestore.instance.collection('Java');
  final CollectionReference LinuxCollection = FirebaseFirestore.instance.collection('Linux');
  final CollectionReference PHPCollection = FirebaseFirestore.instance.collection('PHP');
  final CollectionReference SQLCollection = FirebaseFirestore.instance.collection('SQL');

  Future updateUserNameAndEmail(String username, String useremail) async {
    // if document doesnt exist then firebase will create it automatically
    return await profileCollection.doc(uid).set({
      'username': username,
      'useremail': useremail,
      'python_cq': 1, //current question number (1 by default) for new user
      'sql_cq': 1,
      'html_cq': 1,
      'css_cq': 1,
      'js_cq': 1,
      'cpp_cq': 1,
      'linux_cq': 1,
      'java_cq': 1,
      'comnet_cq':1,
      'db_cq':1,
      'php_cq':1
    });
  }


  // user data from snapshot
  UserData? _userDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return UserData(
      uid: uid,
      username: _snapshot['username'],
      useremail: _snapshot['useremail'],
      python_cq: _snapshot['python_cq'],
      sql_cq: _snapshot['sql_cq'],
      html_cq: _snapshot['html_cq'],
      css_cq: _snapshot['css_cq'],
      js_cq: _snapshot['js_cq'],
      php_cq: _snapshot['php_cq'],
      java_cq: _snapshot['java_cq'],
      linux_cq: _snapshot['linux_cq'],
      cpp_cq: _snapshot['cpp_cq'],
      db_cq: _snapshot['db_cq'],
      comnet_cq: _snapshot['comnet_cq'],
    );
  }

  Stream<UserData?> get currentUserData {
    return profileCollection.doc(uid).snapshots()
    .map(_userDataFromSnapshot);
  }


  // python data from snapshot
  PythonData? _pythonDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return PythonData(
      qno: py_qno,
      rel_qno: _snapshot['rel_qno'],
      level:  _snapshot['level'],
      question:  _snapshot['question'],
      lines_wrong:  _snapshot['lines_wrong'],
      lines_correct:  _snapshot['lines_correct'],
    );
  }

  Stream<PythonData?> get pythonData {
    return pythonCollection.doc(py_qno.toString()).snapshots()
        .map(_pythonDataFromSnapshot);
  }

  pythonDataF() async {
    var snap = await pythonCollection.doc(py_qno.toString()).get();
    if (snap.exists){
      // Map data = snap.data() as Map;
      // print(data['username']);
      return _pythonDataFromSnapshot(snap);

    }else{
      print('data not found');
      return null;
    }
  }


  //php stream
  // php data from snapshot
  PhpData? _phpDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return PhpData(
      qno: php_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<PhpData?> get phpData {
    return PHPCollection.doc(php_qno.toString()).snapshots()
        .map(_phpDataFromSnapshot);
  }

  // HTML
// HTML data from snapshot
  HtmlData? _htmlDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return HtmlData(
      qno: html_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<HtmlData?> get htmlData {
    return HTMLCollection.doc(html_qno.toString()).snapshots()
        .map(_htmlDataFromSnapshot);
  }

// CSS
// CSS data from snapshot
  CssData? _cssDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return CssData(
      qno: css_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<CssData?> get cssData {
    return CSSCollection.doc(css_qno.toString()).snapshots()
        .map(_cssDataFromSnapshot);
  }

//JS
// Js data from snapshot
  JsData? _jsDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return JsData(
      qno: js_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<JsData?> get jsData {
    return JSCollection.doc(js_qno.toString()).snapshots()
        .map(_jsDataFromSnapshot);
  }

//Java
// Java data from snapshot
  JavaData? _javaDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return JavaData(
      qno: java_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<JavaData?> get javaData {
    return JavaCollection.doc(java_qno.toString()).snapshots()
        .map(_javaDataFromSnapshot);
  }

//SQL
// SQL data from snapshot
  SqlData? _sqlDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return SqlData(
      qno: sql_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<SqlData?> get sqlData {
    return SQLCollection.doc(sql_qno.toString()).snapshots()
        .map(_sqlDataFromSnapshot);
  }

//Linux
// Linux data from snapshot
  LinuxData? _linuxDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return LinuxData(
      qno: linux_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<LinuxData?> get linuxData {
    return LinuxCollection.doc(linux_qno.toString()).snapshots()
        .map(_linuxDataFromSnapshot);
  }

//DBMS
// DBMS data from snapshot
  DbData? _dbDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return DbData(
      qno: db_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<DbData?> get dbData {
    return DBCollection.doc(db_qno.toString()).snapshots()
        .map(_dbDataFromSnapshot);
  }

//Com Net
// Com Net data from snapshot
  ComNetData? _comnetDataFromSnapshot(DocumentSnapshot snapshot) {
    final _snapshot = snapshot.data() as Map; //dictionary
    return ComNetData(
      qno: comnet_qno,
      question:  _snapshot['question'],
      optionA:  (_snapshot['options'] as Map)['A'],
      optionB:  (_snapshot['options'] as Map)['B'],
      optionC:  (_snapshot['options'] as Map)['C'],
      optionD:  (_snapshot['options'] as Map)['D'],
      correct_ans:  _snapshot['correct'],
    );
  }

  Stream<ComNetData?> get comnetData {
    return ComNetCollection.doc(comnet_qno.toString()).snapshots()
        .map(_comnetDataFromSnapshot);
  }

} // Database Service