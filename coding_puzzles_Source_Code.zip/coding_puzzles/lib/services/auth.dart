import 'package:coding_puzzles/screens/authenticate/sign_in.dart';
import 'package:coding_puzzles/services/database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:coding_puzzles/models/user.dart';

class AuthService {

  // create firebase auth instance
  // _auth is private
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // create user object based on firebase user
  // FirebaseUser changed to User and AuthResult changed to UserCredential in
  // new firebase_auth versions

  UserC? _userFromFirebaseUser(User? user) {
    return user != null ? UserC(uid: user.uid) : null;
  }

  // auth change user stream
  // Check whether user is logged in or not
  Stream<UserC?> get user {
    // UserC is our custom class
    // This will just convert incoming user class from firebase into our UserC object
    //onAuthStateChanged is replace with authStateChanges in new package
    return _auth.authStateChanges().map((User? user) => _userFromFirebaseUser(user));
  }


  // sign in anonymously (async task bcoz it takes time to perform)
  Future signInAnon() async {
    try {
      UserCredential result = await _auth.signInAnonymously();
      User? user = result.user;
      return _userFromFirebaseUser(user);
      // output format:
      // User(displayName: null, email: null, emailVerified: false,
      // isAnonymous: true,
      // metadata: UserMetadata(creationTime: 2021-12-21 20:29:24.027,
      // lastSignInTime: 2021-12-21 20:29:24.027), phoneNumber: null,
      // photoURL: null, providerData, [], refreshToken: , tenantId: null,
      // uid: w21fh96I2WTy4s4REQMVHNQNtY63)
      // this uid is useful
    } catch(e){
      print('auth try catch error');
      print(e.toString());
      return null;

    }
  }


  // sign in with email and password
  Future signInWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(email: email, password: password);
      User? user = result.user;
      return _userFromFirebaseUser(user);
    } catch(e){
      print(e.toString());
      return null;
    }
  }


  // register with email and password
  Future registerWithEmailAndPassword(String email, String password, String username) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      User? user = result.user;

      // update user details to firestore
      await DatabaseService(uid: user?.uid).updateUserNameAndEmail(username, email);

      return _userFromFirebaseUser(user);
    } catch(e){
      print(e.toString());
      return null;
    }
  }


  // sign out
  Future signOut() async {
    try{
      return await _auth.signOut();
    }catch(e){
      print('Try catch for sign out in auth.dart');
      print(e.toString());
      return null;
    }

  }

}
