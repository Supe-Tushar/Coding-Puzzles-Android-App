import 'package:coding_puzzles/screens/home/home.dart';
import 'package:flutter/material.dart';

class UnderConstruction extends StatefulWidget {
  final dynamic langType;

  const UnderConstruction({this.langType});

  @override
  State<UnderConstruction> createState() => _UnderConstructionState();
}

class _UnderConstructionState extends State<UnderConstruction> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.grey[600],
        title: Text(
          widget.langType ?? 'Under Construction',
          style: const TextStyle(fontSize: 25.0),
        ),
        elevation: 0.0,
        actions: <Widget>[
          // FlatButton is deprecated
          IconButton(
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(builder: (context) => Home()),
              );
            },
            icon: const Icon(Icons.pie_chart),
            //label: Text('Dashboard'),
            //style: TextButton.styleFrom(primary: Colors.white,),
          )
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 150.0,
            width: 150.0,
            decoration: const BoxDecoration(
              shape: BoxShape.rectangle,
              //border: Border.all(color: Colors.red),
              image: DecorationImage(
                image: AssetImage(
                  'images/logo_gif_crop_compr.gif',
                ),
                fit: BoxFit.scaleDown,
              ),
              //borderRadius: BorderRadius.all(Radius.circular(20.0))
            ),
            //child: Image.asset('images/logo_unpadded.gif'),
          ),
          const SizedBox(
            height: 50,
          ),
          Container(
            height: 50.0,
            alignment: Alignment.center,
            child: const Text(
              'Page under construction ...',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                fontSize: 30.0,
                color: Colors.green,
                decoration: TextDecoration.none,
              ),
            ),
          )
        ],
      ),
    );
  }
}