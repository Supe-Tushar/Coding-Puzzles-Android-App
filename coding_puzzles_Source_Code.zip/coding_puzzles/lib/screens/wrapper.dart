import 'package:flutter/material.dart';
import 'package:coding_puzzles/screens/authenticate/authenticate.dart';
import 'package:provider/provider.dart';
import 'package:coding_puzzles/models/user.dart';
import 'package:coding_puzzles/screens/home/home.dart';


//import 'package:coding_puzzles/screens/home/php_quiz.dart';
// import 'package:coding_puzzles/screens/splash.dart';
 //import 'package:coding_puzzles/screens/loading.dart';
// import 'package:coding_puzzles/screens/home/puzzle.dart';
// import 'package:coding_puzzles/screens/under_construction.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Continuous value of user will be available here
    final user = Provider.of<UserC?>(context);

    // return Home or Authenticate depending on whether user is signed in or not
    if (user != null) {
      return Home();
    } else {
      return Authenticate();
    }
  }
}
