import 'package:coding_puzzles/models/python.dart';
import 'package:coding_puzzles/models/user.dart';
import 'package:flutter/material.dart';
import 'package:coding_puzzles/services/auth.dart';
import 'package:coding_puzzles/screens/home/home.dart';
import 'package:coding_puzzles/screens/home/draggable_lines.dart';
import 'package:drag_and_drop_lists/drag_and_drop_lists.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:coding_puzzles/services/database.dart';


class Pair<T1,T2>{
  final T1 a;
  final T2 b;
  Pair(this.a, this.b);
}

class Puzzle extends StatefulWidget {

  final dynamic langType;
  final dynamic python_cq_for_user;

  const Puzzle({ this.langType, this.python_cq_for_user });

  @override
  State<Puzzle> createState() => _PuzzleState();
}

class _PuzzleState extends State<Puzzle> {

  // create instance of AuthService from auth.dart
  final AuthService _auth = AuthService();

   List updatedLinesA = [] ;
    List updatedLinesB = [] ;

   List<DragAndDropList> lists = [];

   bool isCorrect = false;
   //bool codeOP = false;

   //PythonData? pythonData ;

  bool isTupleCreated = false;
  List correctLines = []; //tuple format (line, tab)

  var a = '';
  var b = '';


  @override
  void initState() {
    super.initState();
    //lists = allLists.map(buildList).toList();

    // getData().then((value) {
    //   setState(() {
    //     pythonData = value;
    //   });
    // });

    listsasync().then((result) {
      setState(() {
        lists = result.map(buildList).toList();
        print('Lists: ');
        print(lists);
      });
    });
  }

  // Future<PythonData> getData() async {
  //   return await DatabaseService(py_qno: 1).pythonDataF();
  // }

  Future<List<DraggableList>> listsasync() async {
    var pythonData =  await DatabaseService(py_qno: widget.python_cq_for_user).pythonDataF();
    List<listItem> lines = [];
    var wrongLinesDict =  await pythonData!.lines_wrong;
    var correctLinesDict =  pythonData!.lines_correct;


    wrongLinesDict.forEach((k,v) => lines.add(listItem(fixedtitle: v)));

    correctLinesDict.forEach((k,v) {
      v.forEach((k1,v1) {
        if (k1 == 'line'){
          lines.add(listItem(fixedtitle: v1));
        }
      });
    });

    print(lines);

    List<DraggableList> allLists = [
      const DraggableList(header: 'Working Area', items: [],),
      DraggableList(
        header: 'Trash Area',
        items: lines,
      ),
    ];
    return  allLists;
  }

  // check is user output is correct or not (on click Run)
  bool isValid(output, correctLines){
    if (output.length == correctLines.length){
      for (var i=0; i < correctLines.length; i++){
        var title = output[i].child.title.fixedtitle;
        var tab = output[i].child.title.tabcounter.toString();
        print(correctLines.length);
        print('$i $title $tab');
        print(correctLines[i].a);
        print(correctLines[i].b);
        if ((title != correctLines[i].a) || (tab != correctLines[i].b)){
          return false;
        }
      }
      return true;
    }
  else{
    return false;
  }
  }

  bool validateOutput(output, correct) {
    if (output.length == 0){
      return false;
    }else {
      if (isTupleCreated){
        return isValid(output, correctLines);

      }else{
        // one time tuple list creation
        correct.forEach((k,v) {
          v.forEach((k1,v1) {
            if (k1 == 'line'){
               a = v1;
            }
            if (k1 == 'tabs'){
               b = v1.toString();
            }
          });
          correctLines.add(Pair(a,b));
        });
        isTupleCreated = true;
        print('Tuple is created: $correctLines');
        for (var i=0; i < correctLines.length; i++){
          print(correctLines[i].a);
          print(correctLines[i].b);
        }
        return isValid(output, correctLines);
      }
    }

  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserC?>(context);
    return StreamBuilder<UserData?>(
        stream: DatabaseService(uid: user?.uid).currentUserData,
        builder: (context, snapshot1) {
          return StreamBuilder<PythonData?>(
              stream: DatabaseService(py_qno: widget.python_cq_for_user).pythonData,
              builder: (context, snapshot2) {
                if ((snapshot1.hasData) && (snapshot2.hasData)) {
                  UserData? userData = snapshot1.data;
                  PythonData? pythonData = snapshot2.data;

                  // print('snapshot1 data:');
                  // print(snapshot1.data);
                  // print(user?.uid);
                  // print('python snapshot data:');
                  // print('qno: '+ pythonData!.qno.toString());
                  // print('rel_qno: '+ pythonData.rel_qno.toString());
                  // print('level: '+ pythonData.level.toString());
                  // print('question: '+ pythonData.question);
                  // print('lines_wrong: '+ pythonData.lines_wrong.toString());
                  // print('lines_correct: '+ pythonData.lines_correct.toString());

                  return Scaffold(
                    backgroundColor: Colors.grey[200],
                    appBar: AppBar(
                      backgroundColor: Colors.grey[600],
                      title: Text(
                        widget.langType + ': ' +
                            pythonData?.rel_qno.toString() + '/10' +
                            ' [Level: ' + pythonData?.level.toString() + ']',
                        // insert question number and level (10 Q per level)
                        style: const TextStyle(
                            fontSize: 25.0
                        ),
                      ),
                      elevation: 0.0,
                      actions: <Widget>[
                        // FlatButton is deprecated
                        IconButton(
                          onPressed: () {
                            Navigator.pop(context,
                              MaterialPageRoute(builder: (context) => Home()),
                            );
                          },
                          icon: const Icon(Icons.pie_chart),
                          //label: Text('Dashboard'),
                          //style: TextButton.styleFrom(primary: Colors.white,),
                        )
                      ],
                    ),


                    body: Column(
                      children: [
                        // Container(
                        //   padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                        //   //color: Colors.grey[500],
                        //   child: Text(
                        //     'Question No.: 01] [Level: 1]',
                        //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.green),
                        //   ),
                        // ),
                        Container(
                          height: 75.0,
                          width: double.infinity,
                          alignment: Alignment.center,
                          padding: const EdgeInsets.symmetric(
                              vertical: 5.0, horizontal: 8.0),
                          margin: const EdgeInsets.symmetric(
                              vertical: 0.0, horizontal: 0.0),
                          decoration: BoxDecoration(
                            // border: Border.all(color: Colors.black),
                            color: Colors.grey[500],
                          ),
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: Text(((){
                              if (pythonData?.question != null){
                                return pythonData?.question;
                              } else {
                                return 'NA';
                              }
                            }()),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 17.0,
                                color: Colors.white,
                                wordSpacing: 2.0,
                                //letterSpacing: 2.0
                              ),
                            ),
                          ),
                        ),

                        Expanded(
                          child: DragAndDropLists(
                            listPadding: EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 2.0),
                            listInnerDecoration: BoxDecoration(
                                color: Colors.grey[200],
                                //Theme.of(context).canvasColor,
                                //borderRadius: BorderRadius.circular(10),
                                // border: Border.all(color: Colors.black)
                            ),
                            children: lists,
                            itemDivider: Divider(
                                thickness: 2, height: 0.0, color: Colors.black),
                            itemDecorationWhileDragging: BoxDecoration(
                              color: Colors.grey[200],
                              //boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
                            ),
                            //listDragHandle: buildDragHandle(isList: true),
                            removeTopPadding: true,
                            lastItemTargetHeight: 5.0,
                            itemDragHandle: buildDragHandle(),
                            onItemReorder: onReorderListItem,
                            onListReorder: onReorderList,
                          ),
                        ),

                        Container(
                          height: 80.0,
                          padding: const EdgeInsets.symmetric(
                              vertical: 5.0, horizontal: 8.0),
                          margin: const EdgeInsets.symmetric(
                              vertical: 0.0, horizontal: 0.0),
                          decoration: BoxDecoration(
                            // border: Border.all(color: Colors.black),
                            color: Colors.grey[600],
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.vertical,
                                  child: Text((() {
                                    if (isCorrect) {
                                      return 'OUTPUT: Your submission is Correct';
                                    } else {
                                      return 'OUTPUT: Your submission is Wrong';
                                    }
                                  }()),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.normal,
                                      fontSize: 17.0,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(0.0),
                                      margin: EdgeInsets.all(2),
                                      constraints: BoxConstraints.tightFor(
                                          height: 30, width: 80),
                                      decoration: BoxDecoration(
                                        // border: Border.all(color: Colors.deepPurple),
                                      ),
                                      child: ElevatedButton(
                                        child: const Padding(
                                            padding: EdgeInsets.all(0.0),
                                            child: Text(
                                              'Run',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15
                                              ),
                                            )
                                        ),
                                        onPressed: () {
                                          // print(updatedLinesA.length);
                                          // if (updatedLinesA.length > 0) {
                                          //   for (var i=0; i < updatedLinesA.length; i++){
                                          //     var title = updatedLinesA[i].child.title.fixedtitle;
                                          //     var tab = updatedLinesA[i].child.title.tabcounter;
                                          //     print('$tab || $title');
                                          //   }
                                          // }
                                          setState(() {
                                            isCorrect = validateOutput(
                                                updatedLinesA,
                                                pythonData?.lines_correct);
                                            print('Is correct: $isCorrect');
                                          });
                                        },
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(0.0),
                                      margin: EdgeInsets.all(2),
                                      constraints: BoxConstraints.tightFor(
                                          height: 30, width: 80),
                                      decoration: BoxDecoration(
                                        // border: Border.all(color: Colors.deepPurple),
                                      ),
                                      child: ElevatedButton(
                                        child: const Padding(
                                            padding: EdgeInsets.all(0.0),
                                            child: Text(
                                              'Next',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15
                                              ),
                                            )
                                        ),
                                        onPressed: () async {
                                          if (isCorrect) {
                                            // update user data and then push replacement
                                            print(userData?.uid);

                                            DatabaseService().profileCollection.doc(user?.uid).update(
                                                {
                                                  'python_cq': userData?.python_cq + 1
                                                });

                                            print('Data updated');


                                            Navigator.pushReplacement(context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      Puzzle(
                                                          langType: 'Python')),
                                            );
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }
                else {
                  return Scaffold(
                    backgroundColor: Colors.grey[200],
                    appBar: AppBar(
                      backgroundColor: Colors.grey[600],
                      title: Text(
                        widget.langType,
                        style: TextStyle(
                            fontSize: 30.0
                        ),
                      ),
                      elevation: 0.0,
                      actions: <Widget>[
                        // FlatButton is deprecated
                        IconButton(
                          onPressed: () {
                            Navigator.pop(context,
                              MaterialPageRoute(builder: (context) => Home()),
                            );
                          },
                          icon: const Icon(Icons.pie_chart),
                          //label: Text('Dashboard'),
                          //style: TextButton.styleFrom(primary: Colors.white,),
                        )
                      ],
                    ),


                    body: Column(
                        children: [
                          // Container(
                          //   padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                          //   //color: Colors.grey[500],
                          //   child: Text(
                          //     'Question No.: 01] [Level: 1]',
                          //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.green),
                          //   ),
                          // ),
                          Container(
                            height: 75.0,
                            width: double.infinity,
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(
                                vertical: 5.0, horizontal: 8.0),
                            margin: const EdgeInsets.symmetric(
                                vertical: 0.0, horizontal: 0.0),
                            decoration: BoxDecoration(
                              // border: Border.all(color: Colors.black),
                              color: Colors.grey[500],
                            ),
                            child: const Text(
                              'No data found.\nMaximum question reached.',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 25.0,
                                color: Colors.red,
                                wordSpacing: 2.0,
                                //letterSpacing: 2.0
                              ),
                            ),
                          ),
                        ]
                    ),
                  );
                }
              }
          );
        }
    );
  }


  DragHandle buildDragHandle({bool isList = false}) {
    final verticalAlignment = isList
        ? DragHandleVerticalAlignment.top
        : DragHandleVerticalAlignment.center;
    final color = isList ? Colors.blueGrey : Colors.black26;

    return DragHandle(
      verticalAlignment: verticalAlignment,
      child: Container(
        padding: EdgeInsets.only(right: 5.0, left: 5.0),
        child: const Icon(
            Icons.menu,
            color: Colors.black,
          size: 25.0,
        ),
      ),
    );
  }


  DragAndDropList buildList(DraggableList list) => DragAndDropList(
    header: Container(
      color: Colors.black,
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
      child: Text(
        list.header,
        style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          color: Colors.white,
        ),
      ),
    ),
    canDrag: false,
    children: list.items.map((item) => DragAndDropItem(
      child: ListTile(
        dense: true,
        contentPadding: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 2.0),
        title: item,
      ),
    )).toList(),
    contentsWhenEmpty: const Text(
      'Empty Area',
      style: TextStyle(
        fontStyle: FontStyle.italic,
        fontSize: 15.0,
      ),
    ),
  );

  void onReorderListItem(
      int oldItemIndex,
      int oldListIndex,
      int newItemIndex,
      int newListIndex,
      ) {
    setState(() {
      print('$oldItemIndex  $oldListIndex  $newItemIndex  $newListIndex');
      final oldListItems = lists[oldListIndex].children;
      final newListItems = lists[newListIndex].children;

      final movedItem = oldListItems.removeAt(oldItemIndex);
      newListItems.insert(newItemIndex, movedItem);
      //print(newListItems[0].child);
      updatedLinesA = lists[0].children ;//newListItems;
      updatedLinesB = oldListItems;
    });
  }

  void onReorderList(
      int oldListIndex,
      int newListIndex,
      ) {
    setState(() {
      final movedList = lists.removeAt(oldListIndex);
      lists.insert(newListIndex, movedList);
    });
  }
}