import 'package:coding_puzzles/constants/const_for_home.dart';
import 'package:coding_puzzles/screens/home/css_quiz.dart';
import 'package:coding_puzzles/screens/home/db_quiz.dart';
import 'package:coding_puzzles/screens/home/java_quiz.dart';
import 'package:coding_puzzles/screens/home/js_quiz.dart';
import 'package:coding_puzzles/screens/home/linux_quiz.dart';
import 'package:coding_puzzles/screens/home/php_quiz.dart';
import 'package:coding_puzzles/screens/home/html_quiz.dart';
import 'package:coding_puzzles/screens/home/sql_quiz.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:coding_puzzles/services/auth.dart';
import 'package:coding_puzzles/services/database.dart';
import 'package:coding_puzzles/models/user.dart';
import 'package:coding_puzzles/screens/home/puzzle.dart';
import 'package:coding_puzzles/screens/under_construction.dart';

import 'package:coding_puzzles/screens/loading.dart';

// import 'package:coding_puzzles/models/python.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // create instance of AuthService from auth.dart
  final AuthService _auth = AuthService();

  double col_height = 35.0;
  double col_width_1 = 0.0;
  double col_width_2 = 110.0;
  double col_width_3 = 70.0;
  double col_width_4 = 70.0;
  dynamic color_1 = Colors.cyanAccent;
  dynamic color_2 = Colors.lightGreenAccent;
  dynamic color_head = Colors.lightGreen;




  //final String userId = DatabaseService().currentUserID as String;
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserC?>(context);
    col_width_1 = MediaQuery.of(context).size.width - col_width_2 -col_width_3 - col_width_4 - 30.0 - 10.0;
    return StreamBuilder<UserData?>(
        stream: DatabaseService(uid: user?.uid).currentUserData,
        builder: (context, snapshot) {
          // print('snapshot data:');
          // print(snapshot.data);
          // print(user?.uid);

          if (snapshot.hasData) {
            UserData? userData = snapshot.data;

            return Scaffold(
                backgroundColor: Colors.grey[200],
                appBar: AppBar(
                  backgroundColor: Colors.grey[600],
                  title: const Text('Dashboard'),
                  elevation: 0.0,
                  actions: <Widget>[
                    // FlatButton is deprecated
                    TextButton.icon(
                      onPressed: () async {
                        await _auth.signOut();
                      },
                      icon: Icon(Icons.person),
                      label: Text('Logout'),
                      style: TextButton.styleFrom(
                        //backgroundColor: Colors.grey[600],
                        primary: Colors.white,
                      ),
                    )
                  ],
                ),
                body: Container(
                    padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                    child: SingleChildScrollView(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                          SizedBox(height: 10.0),
                          Container(
                            constraints: BoxConstraints(maxWidth: 300),
                            alignment: Alignment.center,
                            child: Text(
                              'Welcome ' + userData?.username,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.italic,
                                fontSize: 30.0,
                                color: Colors.pink,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 30.0),
                          TitleContainer(textdata: 'Coding Practice',),
                          const SizedBox(height: 15.0,),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                ButtonForHome(
                                  pushTo: Puzzle(langType: 'Python', python_cq_for_user: userData?.python_cq) ,
                                  buttonTitle: 'Python',),
                              ]),
                          const SizedBox(height: 30.0,),
                          TitleContainer(textdata: 'Theory Quiz',),
                          const SizedBox(height: 15.0,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ButtonForHome(
                                pushTo: HtmlQuiz(langType: 'HTML', html_cq_for_user: userData?.html_cq) ,
                                buttonTitle: 'HTML',),
                              ButtonForHome(
                                pushTo: CssQuiz(langType: 'CSS', css_cq_for_user: userData?.css_cq) ,
                                buttonTitle: 'CSS',),
                              ButtonForHome(
                                pushTo:JsQuiz(langType: 'JS', js_cq_for_user: userData?.js_cq) ,
                                buttonTitle: 'JS',),
                              ButtonForHome(
                                pushTo: PhpQuiz(langType: 'PHP', php_cq_for_user: userData?.php_cq) ,
                                buttonTitle: 'PHP',),
                            ],
                          ),
                          const SizedBox(height: 15.0,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ButtonForHome(
                                pushTo: JavaQuiz(langType: 'JAVA', java_cq_for_user: userData?.java_cq) ,
                                buttonTitle: 'Java',),
                              ButtonForHome(
                                pushTo: SqlQuiz(langType: 'SQL', sql_cq_for_user: userData?.sql_cq) ,
                                buttonTitle: 'SQL',),
                              ButtonForHome(
                                pushTo: UnderConstruction(langType: 'C++') ,
                                buttonTitle: 'C++',),
                              ButtonForHome(
                                pushTo: LinuxQuiz(langType: 'Linux', linux_cq_for_user: userData?.linux_cq) ,
                                buttonTitle: 'Linux',),
                            ],
                          ),
                          const SizedBox(height: 30.0,),
                          TitleContainer(textdata: 'Others Quiz',),
                          const SizedBox(height: 15.0,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              ButtonForHome(
                                pushTo: DbQuiz(langType: 'DBMS', db_cq_for_user: userData?.db_cq) ,
                                buttonTitle: 'DBMS',),
                              ButtonForHome(
                                pushTo: LinuxQuiz(langType: 'ComNet', linux_cq_for_user: userData?.linux_cq) ,
                                buttonTitle: 'Computer Networks',),
                            ],
                          ),
                          const SizedBox(height: 30.0),


                          // progress table
                          TitleContainer(textdata: 'Your progress till now:',),
                          const SizedBox(height: 15.0,),
                          Column(
                            children: [
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: 70.0, width: col_width_1, color: color_head,
                                      textdata: 'Topic/\nLang',),
                                    ProgressContainer(
                                      height: 70.0, width: col_width_2, color: color_head,
                                      textdata: 'Ques\nSolved',),
                                    ProgressContainer(
                                      height:70.0, width:col_width_3, color: color_head,
                                      textdata: 'Level',),
                                    ProgressContainer(
                                      height:70.0, width:col_width_4, color: color_head,
                                      textdata: 'Reset',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //PYTHON
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'Python',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.python_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.python_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'python_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              // HTML
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_2,
                                      textdata: 'HTML',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_2,
                                      textdata: (userData?.html_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_2,
                                      textdata: ((userData?.html_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'html_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              // CSS
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'CSS',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.css_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.css_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'css_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //JS
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_2,
                                      textdata: 'JS',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_2,
                                      textdata: (userData?.js_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_2,
                                      textdata: ((userData?.js_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'js_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //PHP
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'PHP',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.php_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.php_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'php_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //Java
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_2,
                                      textdata: 'Java',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_2,
                                      textdata: (userData?.java_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_2,
                                      textdata: ((userData?.java_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'java_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //SQL
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'SQL',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.sql_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.sql_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'sql_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //C++
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_2,
                                      textdata: 'C++',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_2,
                                      textdata: (userData?.cpp_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_2,
                                      textdata: ((userData?.cpp_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'cpp_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //Linux
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'Linux',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.linux_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.linux_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'linux_cq',)
                                  ]),

                              const SizedBox(height: 5.0),

                              //DBMS
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_2,
                                      textdata: 'DBMS',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_2,
                                      textdata: (userData?.db_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_2,
                                      textdata: ((userData?.db_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'db_cq',)
                                  ]),

                              const SizedBox(height: 5.0),


                              // networks
                              Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    ProgressContainer(
                                      height: col_height, width: col_width_1, color: color_1,
                                      textdata: 'Com Net',),
                                    ProgressContainer(
                                      height: col_height, width: col_width_2, color: color_1,
                                      textdata: (userData?.comnet_cq - 1).toString(),),
                                    ProgressContainer(
                                      height:col_height, width:col_width_3, color: color_1,
                                      textdata: ((userData?.comnet_cq ~/ 10) + 1).toString(),),
                                    ProgressResetButton(
                                      height:col_height, width:col_width_3, color: color_1,
                                      user_uid: userData?.uid, lang: 'comnet_cq',)
                                  ]),

                              const SizedBox(height: 30.0),
                            ],
                          )
                        ]))));
          } else {
            return Loading();//DataNotFoundHome();
          }
        });
  }
}
