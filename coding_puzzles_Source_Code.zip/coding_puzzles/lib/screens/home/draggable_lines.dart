import 'package:flutter/material.dart';
import 'package:coding_puzzles/services/database.dart';
import 'package:coding_puzzles/models/python.dart';


class DraggableList {
  final String header;
  final List<listItem> items;

  const DraggableList({
    required this.header,
    required this.items,
  });
}


class listItem extends StatefulWidget {

  final String fixedtitle;
  String? title;
  int? tabcounter;

   listItem({
     Key? key,
    required this.fixedtitle,
     this.tabcounter = 0,
     this.title,
}): super(key: key);


  @override
  _listItemState createState() => _listItemState();
}

class _listItemState extends State<listItem> {

  void _incrementTab() {
    setState(() {
      widget.tabcounter = (widget.tabcounter ?? 0) + 1;
      // print(widget.tabcounter);
      widget.title =  ('   '*widget.tabcounter!) + widget.fixedtitle;
    });
  }

  void _decrementTab() {
    setState(() {
      if (widget.tabcounter! > 0) {
        widget.tabcounter = (widget.tabcounter ?? 0) - 1;
        // print(widget.tabcounter);
        widget.title = ('   ' * widget.tabcounter!) + widget.fixedtitle;
      }

    });
  }



  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      //width: 50.0,
      //height: 50.0,
      //constraints: const BoxConstraints.expand(width: 50.0, height: 100.0),
      padding: const EdgeInsets.only(left: 0.0, right: 35.0),
      margin: const EdgeInsets.symmetric(vertical: 0.0, horizontal: 0.0),
      decoration: BoxDecoration(
        // border: Border.all(color: Colors.black),
      ),
      child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Column(
              children: [
                Container(
                  padding: EdgeInsets.all(0.0),
                  constraints: BoxConstraints.tightFor(height: 30, width: 62),
                  decoration: BoxDecoration(
                    // border: Border.all(color: Colors.deepOrange),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.all(0.0),
                        margin: EdgeInsets.all(0.0),
                        constraints: BoxConstraints.tightFor(height: 30, width: 30),
                        decoration: BoxDecoration(
                          // border: Border.all(color: Colors.deepPurple),
                        ),
                        child: IconButton(
                          padding: EdgeInsets.all(0.0),
                          iconSize: 20,
                          onPressed: _decrementTab,
                          icon: const Icon(Icons.remove_circle),
                          color: Colors.blue,
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(0.0),
                        margin: EdgeInsets.all(0.0),
                        constraints: BoxConstraints.tightFor(height: 30, width: 30),
                        decoration: BoxDecoration(
                          // border: Border.all(color: Colors.deepPurple),
                        ),
                        child: IconButton(
                          padding: EdgeInsets.all(0.0),
                          iconSize: 20,
                          onPressed: _incrementTab,
                          icon: const Icon(Icons.add_circle),
                          color: Colors.blue,
                        ),
                      ),
                    ],
                  ),
                ),


              ],
          ),

            Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Text(
                    widget.title ?? widget.fixedtitle,
                    style: const TextStyle(
                      fontSize: 17.0,
                      //fontWeight: FontWeight.bold,
                      letterSpacing: 2.0,
                      wordSpacing: 3.0,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
      ],
      ),
    );
  }
}




//
// StreamBuilder<PythonData>(
//     stream: DatabaseService(py_qno: 1).pythonData,
//     builder: (context, snapshot) {
//
//       if (snapshot.hasData) {
//         PythonData? pythonData = snapshot.data;
//
//         List<listItem> lines = pythonData!.lines_wrong.entries.map( (entry) => listItem(fixedtitle: entry.value)).toList();
//
//       }
//     }
// );





//
//
// InputLines()  async {
//
//   var pythonData =  DatabaseService().pythonDataF();
//   List<listItem> lines = await pythonData!.lines_wrong.entries.map( (entry) => listItem(fixedtitle: entry.value)).toList();
//
//   return lines;
//
// }






//
//
// class InputLines {
//
//   final int qno;
//
//   List? linesList;
//
//   InputLines({ required this.qno}) {
//     StreamBuilder<PythonData?>(
//         stream: DatabaseService(py_qno: qno).pythonData,
//     builder: (context, snapshot) {
//
//           if (snapshot.hasData) {
//           PythonData? pythonData = snapshot.data;
//
//           List<listItem> lines = pythonData!.lines_wrong.entries.map( (entry) => listItem(fixedtitle: entry.value)).toList();
//           linesList = lines;
//           return linesList;
//           } else {
//
//           }
//         }
//         );
//   }
//
// }
//
//
//









// class DraggableListItem {
//   final String title;
//
//   const DraggableListItem({
//     required this.title,
//   });
// }
//
//
// List<DraggableList> allLists = [
//   DraggableList(
//     header: 'Working Area',
//     items: [
//       DraggableListItem(
//         itemW: Row(
//           mainAxisAlignment: MainAxisAlignment.start,
//           children: [
//             TextButton.icon(
//               onPressed: () {
//
//               },
//               icon: Icon(Icons.add_circle),
//               label: Text('T'),
//               style: TextButton.styleFrom(
//                 primary: Colors.blue,
//               ),
//             ),
//             TextButton.icon(
//               onPressed: () {
//
//               },
//               icon: Icon(Icons.remove_circle),
//               label: Text('T'),
//               style: TextButton.styleFrom(
//                 primary: Colors.blue,
//               ),
//             ),
//             Text('line 1'),
//           ],
//         ),
//         title: 'Line 1',
//       ),
//       // DraggableListItem(
//       //   title: 'Line 2',
//       // ),
//       // DraggableListItem(
//       //   title: 'Line 3',
//       // ),
//       // DraggableListItem(
//       //   title: 'Line 4',
//       // ),
//     ],
//   ),
//   DraggableList(
//     header: 'Trash Area',
//     items: [
//       DraggableListItem(
//           title: 'Line 1',
//           itemW: Row(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               TextButton.icon(
//                 onPressed: () {
//
//                 },
//                 icon: Icon(Icons.add_circle),
//                 label: Text('T'),
//                 style: TextButton.styleFrom(
//                   primary: Colors.blue,
//                 ),
//               ),
//               TextButton.icon(
//                 onPressed: () {
//
//                 },
//                 icon: Icon(Icons.remove_circle),
//                 label: Text('T'),
//                 style: TextButton.styleFrom(
//                   primary: Colors.blue,
//                 ),
//               ),
//               Text('line 1'),
//             ],
//           )
//       ),
//     ],
//   ),
// ];
