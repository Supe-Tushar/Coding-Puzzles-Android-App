import 'package:coding_puzzles/models/lang_models.dart';
import 'package:coding_puzzles/models/user.dart';
import 'package:coding_puzzles/screens/loading.dart';
import 'package:coding_puzzles/services/database.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:coding_puzzles/screens/home/home.dart';


class LinuxQuiz extends StatefulWidget {
  final dynamic langType;
  final dynamic linux_cq_for_user;

  const LinuxQuiz({this.langType, this.linux_cq_for_user});

  @override
  _LinuxQuizState createState() => _LinuxQuizState();
}

class _LinuxQuizState extends State<LinuxQuiz> {
  bool isCorrect = false;
  String correct_ans = '';
  String selected_ans = '';
  bool isSelectedA = false;
  bool isSelectedB = false;
  bool isSelectedC = false;
  bool isSelectedD = false;

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserC?>(context);
    return StreamBuilder<UserData?>(
        stream: DatabaseService(uid: user?.uid).currentUserData,
        builder: (context, snapshot1) {
          return StreamBuilder<LinuxData?>(
              stream: DatabaseService(linux_qno: widget.linux_cq_for_user).linuxData,
              builder: (context, snapshot2) {
                if ((snapshot1.hasData) && (snapshot2.hasData)) {
                  UserData? userData = snapshot1.data;
                  LinuxData? linuxData = snapshot2.data;

                  return Scaffold(
                    backgroundColor: Colors.grey[200],
                    appBar: AppBar(
                      backgroundColor: Colors.grey[600],
                      title: Text(
                        widget.langType + ': Q.no.  ' + linuxData?.qno.toString() ,
                        // insert question number and level (10 Q per level)
                        style: const TextStyle(fontSize: 25.0),
                      ),
                      elevation: 0.0,
                      actions: <Widget>[
                        // FlatButton is deprecated
                        IconButton(
                          onPressed: () {
                            Navigator.pop(
                              context,
                              MaterialPageRoute(builder: (context) => Home()),
                            );
                          },
                          icon: const Icon(Icons.pie_chart),
                          //label: Text('Dashboard'),
                          //style: TextButton.styleFrom(primary: Colors.white,),
                        )
                      ],
                    ),
                    body: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          height: MediaQuery.of(context).size.height - 170.0,
                          width: double.maxFinite,
                          padding: const EdgeInsets.symmetric(
                              vertical: 5.0, horizontal: 2.0),
                          margin: const EdgeInsets.symmetric(
                              vertical: 5.0, horizontal: 5.0),
                          decoration: BoxDecoration(
                            //border: Border.all(color: Colors.black),
                            //color: Colors.grey[600],
                          ),
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  width: double.maxFinite,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5.0, horizontal: 10.0),
                                  margin: const EdgeInsets.symmetric(
                                      vertical: 3.0, horizontal: 3.0),
                                  decoration: BoxDecoration(
                                    //border: Border.all(color: Colors.black),
                                    //color: Colors.grey[600],
                                  ),
                                  child: Text(
                                    ((){
                                      if (linuxData?.question != null){
                                        return linuxData?.question;
                                      } else {
                                        return 'NA';
                                      }
                                    }()),
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20.0,
                                        color: Colors.black),
                                  ),
                                ),
                                Container(
                                  width: double.maxFinite,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10.0, horizontal: 3.0),
                                  margin: const EdgeInsets.symmetric(
                                      vertical: 3.0, horizontal: 3.0),
                                  decoration: BoxDecoration(
                                    //border: Border.all(color: Colors.black),
                                    //color: Colors.grey[600],
                                  ),
                                  child: Column(
                                    children: [
                                      const SizedBox(
                                        height: 10.0,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          child: Text(
                                            ((){
                                              if (linuxData?.optionA != null){
                                                return linuxData?.optionA ;
                                              } else {
                                                return '---';
                                              }
                                            }()),
                                            style: TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 20.0,
                                                color: Colors.black),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 5.0, horizontal: 10.0),
                                            elevation: 10.0,
                                            primary: isSelectedA
                                                ? Colors.lightGreenAccent
                                                : Colors.tealAccent,
                                          ),
                                          onPressed: () {
                                            setState(() {
                                              isSelectedA = true;
                                              isSelectedB = false;
                                              isSelectedC = false;
                                              isSelectedD = false;
                                              selected_ans = 'A';
                                            });
                                          },
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 10.0,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          child: Text(((){
                                            if (linuxData?.optionB != null){
                                              return linuxData?.optionB ;
                                            } else {
                                              return '---';
                                            }
                                          }()),
                                            style: const TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 20.0,
                                                color: Colors.black),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5.0, horizontal: 10.0),
                                            elevation: 10.0,
                                            primary: isSelectedB
                                                ? Colors.lightGreenAccent
                                                : Colors.tealAccent,
                                          ),
                                          onPressed: () {
                                            setState(() {
                                              isSelectedA = false;
                                              isSelectedB = true;
                                              isSelectedC = false;
                                              isSelectedD = false;
                                              selected_ans = 'B';
                                            });
                                          },
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 10.0,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          child: Text(((){
                                            if (linuxData?.optionC != null){
                                              return linuxData?.optionC ;
                                            } else {
                                              return '---';
                                            }
                                          }()),
                                            style: const TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 20.0,
                                                color: Colors.black),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5.0, horizontal: 10.0),
                                            elevation: 10.0,
                                            primary: isSelectedC
                                                ? Colors.lightGreenAccent
                                                : Colors.tealAccent,
                                          ),
                                          onPressed: () {
                                            setState(() {
                                              isSelectedA = false;
                                              isSelectedB = false;
                                              isSelectedC = true;
                                              isSelectedD = false;
                                              selected_ans = 'C';
                                            });
                                          },
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 10.0,
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          child: Text(
                                            ((){
                                              if (linuxData?.optionD != null){
                                                return linuxData?.optionD ;
                                              } else {
                                                return '---';
                                              }
                                            }()),
                                            style: const TextStyle(
                                                fontWeight: FontWeight.normal,
                                                fontSize: 20.0,
                                                color: Colors.black),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5.0, horizontal: 10.0),
                                            elevation: 10.0,
                                            primary: isSelectedD
                                                ? Colors.lightGreenAccent
                                                : Colors.tealAccent,
                                          ),
                                          onPressed: () {
                                            setState(() {
                                              isSelectedA = false;
                                              isSelectedB = false;
                                              isSelectedC = false;
                                              isSelectedD = true;
                                              selected_ans = 'D';
                                            });
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: 80.0,
                          child: Row(
                            children: [
                              Expanded(
                                child: SingleChildScrollView(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5.0, horizontal: 5.0),
                                  scrollDirection: Axis.vertical,
                                  child: Text(
                                    (() {
                                      if (isCorrect) {
                                        return 'OUTPUT: Your answer is Correct';
                                      } else {
                                        return 'OUTPUT: Your answer is Wrong';
                                      }
                                    }()),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.normal,
                                      fontSize: 17.0,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.all(0.0),
                                      margin: EdgeInsets.all(5.0),
                                      constraints: BoxConstraints.tightFor(
                                          height: 30, width: 80),
                                      decoration: BoxDecoration(
                                        //border: Border.all(color: Colors.deepPurple),
                                      ),
                                      child: ElevatedButton(
                                        child: const Padding(
                                            padding: EdgeInsets.all(0.0),
                                            child: Text(
                                              'Check',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15),
                                            )),
                                        onPressed: () {
                                          if (correct_ans == ''){
                                            setState(() {
                                              correct_ans = linuxData?.correct_ans;
                                            });
                                          }

                                          if (selected_ans == correct_ans) {
                                            setState(() {
                                              isCorrect = true;
                                              // print('Is correct: $isCorrect');
                                            });
                                          } else {
                                            setState(() {
                                              isCorrect = false;
                                              // print('Is correct: $isCorrect');
                                            });
                                          }
                                        },
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(0.0),
                                      margin: EdgeInsets.all(5.0),
                                      constraints: BoxConstraints.tightFor(
                                          height: 30, width: 80),
                                      decoration: BoxDecoration(
                                        //border: Border.all(color: Colors.deepPurple),
                                      ),
                                      child: ElevatedButton(
                                        child: const Padding(
                                            padding: EdgeInsets.all(0.0),
                                            child: Text(
                                              'Next',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15),
                                            )),
                                        onPressed: () async {
                                          if (isCorrect) {
                                            // update user data and then push replacement
                                            // print(userData?.uid);
                                            //
                                            DatabaseService().profileCollection.doc(user?.uid).update(
                                                {
                                                  'linux_cq': userData?.linux_cq + 1
                                                });
                                            // print('Data updated');
                                            //await Future.delayed(const Duration(seconds: 1));
                                            Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      LinuxQuiz(langType: 'Linux', linux_cq_for_user: widget.linux_cq_for_user+1,)),
                                            );
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                } else {
                  return Loading();
                }
              });
        });
  }
}
