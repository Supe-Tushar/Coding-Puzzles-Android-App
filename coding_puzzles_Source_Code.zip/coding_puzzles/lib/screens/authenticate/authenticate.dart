import 'package:flutter/material.dart';
import 'package:coding_puzzles/screens/authenticate/sign_in.dart';
import 'package:coding_puzzles/screens/authenticate/register.dart';

class Authenticate extends StatefulWidget {
  @override
  _AuthenticateState createState() => _AuthenticateState();
}

class _AuthenticateState extends State<Authenticate> {
  // Switch between sign in and register screens
  bool showSignIn = true;

  // void function not returning any value
  // This function will invert showSignIn value
  void toggleView() {
    setState(() => showSignIn = !showSignIn);
  }

  @override
  Widget build(BuildContext context) {
    if (showSignIn) {
      // property:function name sent to views
      // property name can be anything
      return SignIn(toggleView: toggleView);
    } else {
      return Register(toggleView: toggleView);
    }
  }
}
