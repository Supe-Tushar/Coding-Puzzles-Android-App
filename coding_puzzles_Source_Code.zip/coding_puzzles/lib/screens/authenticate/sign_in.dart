import 'package:coding_puzzles/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:coding_puzzles/screens/loading.dart';

class SignIn extends StatefulWidget {
  // toggleView must be accepted in the widget
  final Function? toggleView;

  SignIn({this.toggleView});

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  // _auth is private so can be used in this file only
  final AuthService _auth =
      AuthService(); // AuthService is class from auth.dart file

  // state variables to store email and password
  String email = '';
  String password = '';
  String error = '';

  // Show hide password
  bool _passEnable = true; //  obscure password

  //Loading screen bool
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Loading();
    } else {
      return Scaffold(
        backgroundColor: Colors.grey[200],
        appBar: AppBar(
          backgroundColor: Colors.grey[600],
          elevation: 0.0,
          title: Text('Sign In'),
          actions: <Widget>[
            TextButton.icon(
              onPressed: () {
                // Switches between sign in and register
                widget.toggleView!(); // now its taken from widget instance
              },
              icon: Icon(Icons.person),
              label: Text('Register'),
              style: TextButton.styleFrom(
                //backgroundColor: Colors.grey[600],
                primary: Colors.white,
              ),
            )
          ],
        ),
        body: Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
          child: SingleChildScrollView(
            child: Form(
              child: Column(
                children: <Widget>[
                  SizedBox(height: 30.0),
                  TextFormField(
                    onChanged: (val) {
                      setState(
                              () =>
                          email = val + '@student.onlinedegree.iitm.ac.in');
                    },
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Email Address',
                        labelStyle: TextStyle(fontSize: 20),
                        hintText: 'Enter Email Address',
                        hintStyle: TextStyle(fontSize: 15),
                        suffixText: '@student.onlinedegree.iitm.ac.in',
                        suffixStyle: TextStyle(
                          //fontWeight: FontWeight.bold,
                          fontStyle: FontStyle.italic,
                          fontSize: 15,
                        )),
                  ),
                  SizedBox(height: 30.0),
                  TextFormField(
                    obscureText: _passEnable,
                    // hide password, with icon
                    autocorrect: false,
                    enableSuggestions: false,
                    onChanged: (val) {
                      setState(() => password = val);
                    },
                    decoration: InputDecoration(
                        isDense: true,
                        contentPadding: EdgeInsets.all(8),
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                        labelStyle: TextStyle(fontSize: 20.0),
                        hintText: 'Enter your Password',
                        hintStyle: TextStyle(fontSize: 15),
                        suffix: IconButton(
                          iconSize: 25,
                          //padding: EdgeInsets.all(8),
                          onPressed: () {
                            setState(() {
                              _passEnable = !_passEnable;
                            });
                          },
                          icon: Icon(_passEnable == true
                              ? Icons.remove_red_eye
                              : Icons.password),
                        )),
                  ),
                  SizedBox(height: 30.0),
                  ElevatedButton(
                      onPressed: () async {
                        //email = email + '@student.onlinedegree.iitm.ac.in';
                        //print(email);
                        //print(password);

                        FocusScope.of(context).unfocus();
                        await Future.delayed(Duration(milliseconds: 500));

                        // show loading screen
                        setState(() {
                          loading = true;
                        });

                        // send data to firebase for login
                        dynamic result = await _auth.signInWithEmailAndPassword(
                            email, password);
                        if (result == null) {
                          setState(() {
                            error = 'Error in signing in ';
                            loading = false;
                          });
                        }
                        // else is not needed because then registration will be successful and
                        // due to streams user will be redirected to dashboard

                        else {
                          //print('\nSigned In\n');
                          //print(result.uid);
                        }
                      },
                      child: Text('Sign In')),
                  SizedBox(
                    height: 12.0,
                  ),
                  Text(
                    error,
                    style: TextStyle(color: Colors.red, fontSize: 14.0),
                  )
                ],
              ),
            ),
          ), // for user email and password form
        ),
      );
    }
  }
}

//==============================
// Sign in anonymously Code
// return Scaffold(
// backgroundColor: Colors.grey[200],
// appBar: AppBar(
// backgroundColor: Colors.grey[600],
// elevation: 0.0,
// title: Text('Sign In'),
// ),
// body: Container(
// padding: EdgeInsets.symmetric(vertical: 20, horizontal: 50),
// child: ElevatedButton(
// child: Text('Sign In Anonymously'),
// onPressed: () async{
// // dynamic type bcoz result can be firebase user instance or null.
// dynamic result = await _auth.signInAnon(); // ref: auth.dart
// if (result == null){
// //print('Error in sign in');
// } else{
// //print('Signed in');
// //print(result);
// }
// },
// ),
// ),
// );
