import 'package:flutter/material.dart';
import 'package:coding_puzzles/services/auth.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:coding_puzzles/screens/loading.dart';

class Register extends StatefulWidget {
  // toggleView must be accepted in the widget
  final Function? toggleView;

  Register({this.toggleView});

  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  // _auth is private so can be used in this file only
  final AuthService _auth =
      AuthService(); // AuthService is class from auth.dart file

  // formkey to form validations, it stores state of form
  final _formKey = GlobalKey<FormState>();

  // username  validator with multiple conditions
  final usernameValidator = MultiValidator([
    RequiredValidator(errorText: 'Username is required'),
    MinLengthValidator(4, errorText: 'Minimum length is 4'),
    MaxLengthValidator(8, errorText: 'Maximum length is 8'),
  ]);

  // Password validator with multiple conditions
  final passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password is required'),
    MinLengthValidator(6, errorText: 'Minimum length is 4'),
    MaxLengthValidator(8, errorText: 'Maximum length is 8'),
    PatternValidator(r'(?=.*?[#?!@%$^&*-])',
        errorText: 'Password must have at least one special character'),
  ]);

  // Email validator with multiple conditions.
  // Actual  email value here is without '@student.onlinedegree.iitm.ac.in'
  // Validations are done according to this
  final emailValidator = MultiValidator([
    RequiredValidator(errorText: 'Email is required'),
    MaxLengthValidator(12,
        errorText: 'Enter email excluding "@student.onlinedegree.iitm.ac.in" '),
  ]);

  // state variables to store email and password
  String username = '';
  String email = '';
  String password = '';
  String password2 = ''; // re entered password
  String error = '';

  // Show hide password
  bool _passEnable = true; //  obscure password

  //loading
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Loading();
    } else {
      return Scaffold(
        backgroundColor: Colors.grey[200],
        appBar: AppBar(
          backgroundColor: Colors.grey[600],
          elevation: 0.0,
          title: Text('Register'),
          actions: <Widget>[
            TextButton.icon(
              onPressed: () {
                // Switches between sign in and register
                widget.toggleView!(); // now its taken from widget instance
              },
              icon: Icon(Icons.person),
              label: Text('Sign In'),
              style: TextButton.styleFrom(
                //backgroundColor: Colors.grey[600],
                primary: Colors.white,
              ),
            )
          ],
        ),
        body: Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  SizedBox(height: 30.0),
                  TextFormField(
                    validator: usernameValidator,
                    onChanged: (val) {
                      setState(() => username = val);
                    },
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Username',
                      labelStyle: TextStyle(fontSize: 20),
                      hintText: 'Enter username',
                      hintStyle: TextStyle(fontSize: 15),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  TextFormField(
                    validator: (val) {
                      MultiValidator pv = emailValidator;
                      if (val == null || val.isEmpty) {
                        return 'Please enter email';
                      } else {
                        if ([
                          '@',
                          '.',
                          'student',
                          'onlinedegree',
                          'iitm',
                          'ac',
                          'in'
                        ].map((el) => val.contains(el)).contains(true)) {
                          return "Enter email excluding '@student.onlinedegree.iitm.ac.in'";
                        } else {
                          if (pv.isValid(val)) {
                            return null;
                          } else {
                            return pv.call(val);
                          }
                        }
                      }
                    },
                    onChanged: (val) {
                      setState(() => email = val);
                      // this email val is just id without '@student.onlinedegree.iitm.ac.in'
                    },
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Email Address',
                        labelStyle: TextStyle(fontSize: 20),
                        hintText: 'Enter Email Address',
                        hintStyle: TextStyle(fontSize: 15),
                        suffixText: '@student.onlinedegree.iitm.ac.in',
                        suffixStyle: TextStyle(
                          //fontWeight: FontWeight.bold,
                          fontStyle: FontStyle.italic,
                          fontSize: 15,
                        )),
                  ),
                  SizedBox(height: 30.0),
                  TextFormField(
                    validator: passwordValidator,
                    obscureText: _passEnable,
                    // hide password, with icon
                    autocorrect: false,
                    enableSuggestions: false,
                    onChanged: (val) {
                      setState(() => password = val);
                    },
                    decoration: InputDecoration(
                        isDense: true,
                        contentPadding: EdgeInsets.all(8),
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                        labelStyle: TextStyle(fontSize: 20.0),
                        hintText: 'Enter your Password',
                        hintStyle: TextStyle(fontSize: 15),
                        suffix: IconButton(
                          iconSize: 25,
                          //padding: EdgeInsets.all(8),
                          onPressed: () {
                            setState(() {
                              _passEnable = !_passEnable;
                            });
                          },
                          icon: Icon(_passEnable == true
                              ? Icons.remove_red_eye
                              : Icons.password),
                        )),
                  ),
                  //SizedBox(height: 10.0),
                  TextFormField(
                    // this is instructions for password
                    initialValue:
                        "Password length must be between 6 to 8 chars.\nIt must contain at least one special character among '#' '?' '!' '@' '%' '\$' '^' '&' '*' '-'",
                    maxLines: 3,
                    style: const TextStyle(
                      fontSize: 15.0,
                    ),
                    //readOnly: true, // read only true still creates a text field but just uneditable
                    enabled: true,
                  ),
                  SizedBox(height: 30.0),
                  TextFormField(
                    obscureText: _passEnable,
                    // hide password, with icon
                    autocorrect: false,
                    enableSuggestions: false,
                    onChanged: (val) {
                      setState(() =>
                          password2 = val); // no need to store as password2
                    },
                    validator: (val) {
                      if (val == null || val.isEmpty) {
                        return 'Password is empty';
                      } else {
                        return MatchValidator(
                                errorText: 'Passwords do not match')
                            .validateMatch(val, password);
                      }
                    },
                    decoration: InputDecoration(
                        isDense: true,
                        contentPadding: EdgeInsets.all(8),
                        border: OutlineInputBorder(),
                        labelText: 'Confirm Password',
                        labelStyle: TextStyle(fontSize: 20.0),
                        hintText: 'Re-Enter your Password',
                        hintStyle: TextStyle(fontSize: 15),
                        suffix: IconButton(
                          iconSize: 25,
                          //padding: EdgeInsets.all(8),
                          onPressed: () {
                            setState(() {
                              _passEnable = !_passEnable;
                            });
                          },
                          icon: Icon(_passEnable == true
                              ? Icons.remove_red_eye
                              : Icons.password),
                        )),
                  ),
                  SizedBox(height: 30.0),
                  ElevatedButton(
                      onPressed: () async {
                        // form validations
                        // gets output of all validators fields
                        // Submit email as email + '@student.onlinedegree.iitm.ac.in'
                        if (_formKey.currentState!.validate()) {
                          email = email + '@student.onlinedegree.iitm.ac.in';
                          //print(username);
                          //print(email);
                          //print(password);

                          FocusScope.of(context).unfocus();
                          await Future.delayed(Duration(milliseconds: 500));

                          // loading scree
                          setState(() {
                            loading = true;
                          });

                          // send data to firebase for registration
                          dynamic result =
                              await _auth.registerWithEmailAndPassword(
                                  email, password, username);
                          if (result == null) {
                            setState(() {
                              error = 'Error in registration ';
                              loading = false;
                            });
                          }
                          // else is not needed because then registration will be successful and
                          // due to streams user will be redirected to dashboard

                          else {
                            //print('\nRegistered\n');
                            //print(result.uid);
                          }
                        }
                      },
                      child: Text('Register')),
                  const SizedBox(
                    height: 12.0,
                  ),
                  Text(
                    error,
                    style: TextStyle(color: Colors.red, fontSize: 14.0),
                  )
                ],
              ),
            ),
          ), // for user email and password form
        ),
      );
    }
  }
}
