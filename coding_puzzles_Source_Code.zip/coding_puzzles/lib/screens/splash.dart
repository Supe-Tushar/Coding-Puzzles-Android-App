import 'dart:async';
import 'package:flutter/material.dart';
import 'package:coding_puzzles/screens/wrapper.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    Timer(
        Duration(milliseconds: 3000),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => Wrapper())));
    return SplashScreen();
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white24, Colors.white70])),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            height: 200.0,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              //border: Border.all(color: Colors.red),
              image: DecorationImage(
                image: AssetImage('images/logo.jpg'),
                fit: BoxFit.scaleDown,
              ),
              //borderRadius: BorderRadius.all(Radius.circular(20.0))
            ),
            //child: Image.asset('images/logo_unpadded.gif'),
          ),
          Container(
            height: 120.0,
            child: const Text(
              'Coding\nPuzzles',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                fontSize: 40.0,
                color: Colors.white,
                decoration: TextDecoration.none,
              ),
            ),
          )
        ],
      ),
    );
  }
}
