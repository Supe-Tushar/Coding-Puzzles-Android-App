import 'package:flutter/material.dart';

import 'package:coding_puzzles/screens/home/home.dart';

class Loading extends StatelessWidget {
  const Loading({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.grey[600],
        title: const Text(
          '',
          style: TextStyle(fontSize: 30.0),
        ),
        elevation: 0.0,
        actions: <Widget>[
          // FlatButton is deprecated
          IconButton(
            onPressed: () {
              Navigator.pop(
                context,
                MaterialPageRoute(builder: (context) => Home()),
              );
            },
            icon: const Icon(Icons.pie_chart),
            //label: Text('Dashboard'),
            //style: TextButton.styleFrom(primary: Colors.white,),
          )
        ],
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height - 80.0,
            width: double.infinity,
            decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [
              Colors.white,
              Colors.white,
            ])),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 150.0,
                  width: 150.0,
                  decoration: const BoxDecoration(
                    shape: BoxShape.rectangle,
                    //border: Border.all(color: Colors.red),
                    image: DecorationImage(
                      image: AssetImage(
                        'images/logo_gif_crop_compr.gif',
                      ),
                      fit: BoxFit.scaleDown,
                    ),
                    //borderRadius: BorderRadius.all(Radius.circular(20.0))
                  ),
                  //child: Image.asset('images/logo_unpadded.gif'),
                ),
                const SizedBox(
                  height: 50,
                ),
                Container(
                  height: 50.0,
                  child: const Text(
                    'Loading...',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic,
                      fontSize: 30.0,
                      color: Colors.green,
                      decoration: TextDecoration.none,
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
