import 'package:coding_puzzles/screens/under_construction.dart';
import 'package:coding_puzzles/services/auth.dart';
import 'package:coding_puzzles/services/database.dart';
import 'package:flutter/material.dart';

class DataNotFoundHome extends StatefulWidget {
  @override
  _DataNotFoundHomeState createState() => _DataNotFoundHomeState();
}

class _DataNotFoundHomeState extends State<DataNotFoundHome> {
  final AuthService _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[200],
        appBar: AppBar(
          backgroundColor: Colors.grey[600],
          title: Text('Dashboard'),
          elevation: 0.0,
          actions: <Widget>[
            // FlatButton is deprecated
            TextButton.icon(
              onPressed: () async {
                await _auth.signOut();
              },
              icon: Icon(Icons.person),
              label: Text('Logout'),
              style: TextButton.styleFrom(
                //backgroundColor: Colors.grey[600],
                primary: Colors.white,
              ),
            )
          ],
        ),
        body: Container(
          padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
          child: SingleChildScrollView(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: 10.0),
                  Container(
                    constraints: BoxConstraints(maxWidth: 300),
                    alignment: Alignment.centerLeft,
                    child: const Text(
                      'Data Not Found',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        //fontStyle: FontStyle.italic,
                        fontSize: 30.0,
                        color: Colors.red,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ]),
          ),
        ));
  }
}

class ProgressContainer extends StatefulWidget {
  final dynamic height;
  final dynamic width;
  final dynamic textdata;
  dynamic color;

  ProgressContainer(
      {this.height, this.width, this.textdata, this.color = Colors.cyanAccent});

  @override
  _ProgressContainerState createState() => _ProgressContainerState();
}

class _ProgressContainerState extends State<ProgressContainer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      width: widget.width,
      alignment: Alignment.center,
      padding: EdgeInsets.all(5.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(8.0)),
        color: widget.color,
      ),
      child: Text(
        widget.textdata,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 20.0,
          color: Colors.black,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class ProgressResetButton extends StatefulWidget {
  final String user_uid;
  dynamic lang;
  final dynamic height;
  final dynamic width;
  dynamic color;

  ProgressResetButton(
      {this.height,
      this.width,
      this.color = Colors.cyanAccent,
      required this.user_uid,
      this.lang});

  @override
  _ProgressResetButtonState createState() => _ProgressResetButtonState();
}

class _ProgressResetButtonState extends State<ProgressResetButton> {
  @override
  Widget build(BuildContext context) {
    return Container(
        height: widget.height,
        width: widget.width,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(0.0),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(8.0)),
          //color: widget.color,
        ),
        child: ElevatedButton(
            onPressed: () async {
              await DatabaseService()
                  .profileCollection
                  .doc(widget.user_uid)
                  .update({widget.lang: 1});
            },
            child: Icon(Icons.restore),
            style: ElevatedButton.styleFrom(
                elevation: 10.0,
                primary: Colors.blueAccent)
        )
    );
  }
}

class ButtonForHome extends StatefulWidget {
  dynamic pushTo;
  dynamic buttonTitle;

  ButtonForHome({this.pushTo, this.buttonTitle});

  @override
  _ButtonForHomeState createState() => _ButtonForHomeState();
}

class _ButtonForHomeState extends State<ButtonForHome> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () async {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => widget.pushTo),
        );
      },
      child: Text(
        widget.buttonTitle,
        style: const TextStyle(
          fontSize: 20.0,
          fontWeight: FontWeight.bold,
        ),
      ),
      style: ElevatedButton.styleFrom(
        // padding: const EdgeInsets.symmetric(
        //     vertical: 5.0, horizontal: 5.0),
        elevation: 10.0,
        primary: Colors.blueAccent,
      ),
    );
  }
}

class TitleContainer extends StatefulWidget {
  dynamic textdata;

  TitleContainer({this.textdata});

  @override
  _TitleContainerState createState() => _TitleContainerState();
}

class _TitleContainerState extends State<TitleContainer> {
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 300),
      alignment: Alignment.center,
      child: Text(
        widget.textdata,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 25.0,
          color: Colors.black,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }
}
