package com.example.coding_puzzles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
